public interface StInterface{
    public void setName(String a);
    public void setID(String b);
    public String getName();
    public String getID();
}