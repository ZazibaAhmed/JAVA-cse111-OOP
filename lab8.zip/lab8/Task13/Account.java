public class Account{
    public String name,number,type;
    public double balance;
}
        