public class StudentInfo1{
    public static void main(String []args){
        Student john=new Student();
        Student mike=new Student();
        Student carol=new Student();
        john.setName("john");
        john.setID("1533");
        john.setAddress("Dhanmondi,Dhaka");
        john.setCGPA(3.4);
        mike.setName("mike");
        mike.setID("1678");
        mike.setAddress("Gulshan,Dhaka");
        mike.setCGPA(4.0);
        carol.setName("carol");
        carol.setID("1788");
        carol.setAddress("Banani,Dhaka");
        carol.setCGPA(2.7);
        String j=john.getName()+","+john.getID()+","+john.getAddress()+","+john.getCGPA();
        String m=mike.getName()+","+mike.getID()+","+mike.getAddress()+","+mike.getCGPA();
        String c=carol.getName()+","+carol.getID()+","+carol.getAddress()+","+carol.getCGPA();
        System.out.println(j);
        System.out.println(m);
        System.out.println(c);
    }
}

        
        
        
        
        
           
        
        
        
        
        
       