public class Jackfruit extends Fruit{
    public Jackfruit(){
        /*super.formalin=false;
        super.name="Jackfruits";*/
        super(true,"Mango");
    }
    public String toString(){
        return "Mangos are bad for you";
    }
}