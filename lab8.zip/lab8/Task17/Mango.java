public class Mango extends Fruit{
    public Mango(){
       /* super.formalin=true;
        super.name="Mangos";*/
        super(false,"Jackfruits");
    }
    public String toString(){
        return "Mangos are bad for you";
    }
}