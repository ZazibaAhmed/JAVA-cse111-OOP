public class Violin extends Instrument{
   public void play(){
    System.out.println("In the playing method of Violin");
  }
  public void adjust(){
        System.out.println("In the adjust method of Violin");
  }
}