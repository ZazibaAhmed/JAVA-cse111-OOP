public class Keyboard extends Instrument{
 public void play(){
    System.out.println("In the playing method of Keyboard");
  }
  public void adjust(){
        System.out.println("In the adjust method of Keyboard");
  }
}