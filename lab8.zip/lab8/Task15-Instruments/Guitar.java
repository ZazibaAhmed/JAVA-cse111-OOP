public class Guitar extends Instrument{
  public void play(){
    System.out.println("In the playing method of Guitar");
  }
  public void adjust(){
        System.out.println("In the adjust method of Guitar");
  }
}