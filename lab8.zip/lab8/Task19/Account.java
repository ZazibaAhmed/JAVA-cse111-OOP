public class Account{
  protected double balance = 0.0;
  public Account(){
  }
  public Account(double balance){
    this.balance = balance;
  }
  public double getBalance(){
    return balance;
  }
}
