public class Cat extends Animal{
    Cat(String x){
        super(x);
    }
}