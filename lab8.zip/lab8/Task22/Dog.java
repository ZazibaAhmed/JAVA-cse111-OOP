public class Dog extends Animal{
    Dog(String c){
    super(c);
    }
}