public class Student{
  public String msg = "I love BU";
  public String shout(){
    return msg;
  }
}
