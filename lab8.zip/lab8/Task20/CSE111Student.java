public class CSE111Student extends CSEStudent{
    public CSE111Student(){
        msg = "I love Java Prorgramming";
    }
}