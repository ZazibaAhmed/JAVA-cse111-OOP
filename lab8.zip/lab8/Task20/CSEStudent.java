public class CSEStudent extends Student{
    
    public CSEStudent(){
        msg = "I want to transfer to CSE";
    }
}
    
   