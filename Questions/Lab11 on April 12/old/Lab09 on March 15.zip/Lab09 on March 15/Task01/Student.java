public class Student{
  String name;
  String id;
  int section;
  double mark;
  public String toString(){
      return "Naam: "+name+"\n" 
		+"ID: "+id+"\n" 
		+"Section: "+section+"\n" 
		+"Mark: "+mark+"\n";
  }
}
