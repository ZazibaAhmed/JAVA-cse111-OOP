class A{ // loop = iteration
  public static void main(String[]args){
    B b = new B();
    b.sayHi(3);
  }
}