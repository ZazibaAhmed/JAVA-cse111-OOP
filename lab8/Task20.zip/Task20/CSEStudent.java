public class CSEStudent extends Student{
    
    public String msg;
    public CSEStudent(){
        msg = "I want to transfer to CSE";
    }
    public String shout(){
    msg = "I want to transfer to CSE";
    return msg;
  }
}
    
   