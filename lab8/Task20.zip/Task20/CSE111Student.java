public class CSE111Student extends CSEStudent{
    public String msg;
    public CSE111Student(){
        msg = "I love java programming";
    }
    public String shout(){
    msg = "I love java programming";
    return msg;
}
}